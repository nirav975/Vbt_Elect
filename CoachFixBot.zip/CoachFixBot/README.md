# CoachFix Bot — Android app

Vande Bharat / EMU / MEMU coach maintenance ke liye offline troubleshooting bot.
47 faults, 12 systems (Traction, Pantograph & HT, Brake, Doors, AC, TCMS, Aux/Battery, Bogie, Coupler, Toilet/Water, Amenities, Fire).

## Features
- Chat bot: problem Hinglish me likho (jaise "AC thanda nahi kar raha") ya system chuno
- Har fault ke liye: safety pehle, possible causes, tick karne wale check steps, remedy, escalate kisko
- Fault log (phone par save hota hai): coach/rake no., status (Resolved / Escalated / Pending), notes
- Log ko CSV me WhatsApp / Gmail / Drive par share karo
- Poori internet ke bina chalta hai

## APK kaise banaye

### Option A — GitHub (computer par kuch install nahi karna)
1. github.com par naya repository banao aur is folder ki saari files upload karo (`.github` folder bhi).
2. **Actions** tab kholo → "Build APK" workflow apne aap chalega (ya "Run workflow" dabao).
3. ~5 minute baad run kholo → neeche **Artifacts** me `CoachFixBot-apk` download karo → zip ke andar `app-debug.apk`.
4. APK phone par bhejo aur install karo (Settings me "Install unknown apps" allow karna padega).

### Option B — Android Studio
1. Android Studio (Ladybug ya naya) me **File → Open** karke yeh folder kholo.
2. Gradle sync hone do (pehli baar internet chahiye).
3. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. APK yahan milega: `app/build/outputs/apk/debug/app-debug.apk`.

## Content badalna
- Faults ka data `app/src/main/assets/index.html` ke andar `kb-data` JSON me hai.
- Naye fault add karne ke liye wahi format copy karo: id, system, symptom, keywords, severity, causes, checks, remedy, safety, escalate (lists `|` se alag).

## Zaroori
Yeh general guidance hai. OEM maintenance manual, RDSO / zonal instructions, depot SOP aur safety rules hamesha final hain.
Debug APK depot ke andar sideload ke liye theek hai; Play Store ke liye release signing key configure karni padegi.
